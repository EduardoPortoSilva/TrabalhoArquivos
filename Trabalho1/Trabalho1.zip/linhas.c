/*
    Eduardo Henrique Porto Silva    NUSP 11796656
    Tulio Santana Ramos             NUSP 11795526

    Esse arquivo .c contém as funções relacionadas ao arquivo de linhas
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linhas.h"
#include "gerais.h"